﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CRUDwithRepoCeren.ViewModel
{
    public class ViewDepartment
    {
        //we already have this?
        public int? DepartmentId { get; set; }

        [Required(ErrorMessage = "Please enter department name.")]
        public string DepartmentName { get; set; }

    }
}