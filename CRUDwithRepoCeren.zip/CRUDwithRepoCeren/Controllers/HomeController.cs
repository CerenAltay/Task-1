﻿using CRUDwithRepoCeren.Models;
using CRUDwithRepoCeren.Repository;
using CRUDwithRepoCeren.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CRUDwithRepoCeren.Controllers
{
    public class HomeController : Controller
    {
        //why
        private IDepartment iDepartment;

        public HomeController()
        {
            //why
            iDepartment = new DepartmentRepository();
        }
        public ActionResult Index()
        {
            List<ViewDepartment> lstDepartments = new List<ViewDepartment>();

            //why new Department?
            foreach (var item in iDepartment.GetDepartment(new Department()))
            {
                //why new viewdepartment?
                lstDepartments.Add(new ViewDepartment()
                {
                    DepartmentId = item.DepartmentId,
                    DepartmentName = item.DepartmentName
                });

            }

            return View(lstDepartments);
        }

        [HttpGet]

        public ActionResult Create (int? id)
        {
            ViewDepartment viewDepartment = new ViewDepartment();

            if (id != null)
            {
                Department department = iDepartment.GetDepartment(new Department() { DepartmentId = Convert.ToInt32(id) }).FirstOrDefault();
            }

        }
    }
}