﻿using CRUDwithRepoCeren.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUDwithRepoCeren.Repository
{
    interface IDepartment
    {
        bool AddDepartment(Department department);
        IList<Department> GetDepartment(Department department);
    }
}
