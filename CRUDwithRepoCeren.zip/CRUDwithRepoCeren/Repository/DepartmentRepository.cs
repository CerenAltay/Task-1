﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CRUDwithRepoCeren.Models;

namespace CRUDwithRepoCeren.Repository
{
    public class DepartmentRepository : IDepartment
    {
        public bool AddDepartment(Department department)
        {
            bool IsSuccess = false;
            try
            {
                using (EmployeeEntities dbContext = new EmployeeEntities())
                {
                    dbContext.Departments.Add(department);
                    dbContext.SaveChanges();
                }
                IsSuccess = true;
            }
            catch(Exception ex)
            {

            }
            return IsSuccess;

        }

        public IList<Department> GetDepartment(Department department)
        {
           IList<Department> lstDepartments = new List<Department>();

            using (EmployeeEntities dbContext = new EmployeeEntities())
            {
                lstDepartments = dbContext.Departments.ToList();

                if (department.DepartmentId != 0)
                    lstDepartments = lstDepartments.Where(x => x.DepartmentId == department.DepartmentId).ToList();
            }
            return lstDepartments;
        }
    }
}