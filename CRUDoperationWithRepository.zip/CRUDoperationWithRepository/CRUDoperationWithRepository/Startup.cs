﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CRUDoperationWithRepository.Startup))]
namespace CRUDoperationWithRepository
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
