﻿using CRUDoperationWithRepository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUDoperationWithRepository.Repository
{
    interface IDepartment
    {
        bool AddDepartment(Department department);
        List<Department> GetDepartment(Department department);
    }
}
