﻿using CRUDoperationWithRepository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CRUDoperationWithRepository.Repository
{
    public class DepartmentRepository : IDepartment
    {
        public bool AddDepartment(Department department)
        {
            bool IsSuccess = false;
            try
            {
                using (EmployeeManagementEntities dbContext = new EmployeeManagementEntities())
                {
                    dbContext.Departments.Add(department);
                    dbContext.SaveChanges();
                }
                IsSuccess = true;
            }
            catch (Exception ex)
            {

            }
            return IsSuccess;
        }


        public List<Department> GetDepartment(Department department)
        {
            List<Department> lstDepartments = new List<Department>();

            using (EmployeeManagementEntities dbContext = new EmployeeManagementEntities())
            {
                lstDepartments = dbContext.Departments.ToList();

                if (department.DepartmentId != 0)
                    lstDepartments = lstDepartments.Where(x => x.DepartmentId == department.DepartmentId).ToList();
            }

            return lstDepartments;
        }
    }
}