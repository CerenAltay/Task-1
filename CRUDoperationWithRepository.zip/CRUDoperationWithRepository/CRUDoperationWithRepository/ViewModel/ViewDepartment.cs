﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CRUDoperationWithRepository.ViewModel
{
    public class ViewDepartment
    {
        public int? DepartmentId { get; set; }

        [Required(ErrorMessage = "Please enter department name.")]
        public string DepartmentName { get; set; }
    }
}