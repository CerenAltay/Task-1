﻿using CRUDoperationWithRepository.Models;
using CRUDoperationWithRepository.Repository;
using CRUDoperationWithRepository.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CRUDoperationWithRepository.Controllers
{
    public class HomeController : Controller
    {
        private IDepartment iDepartment;

        public HomeController()
        {
            iDepartment = new DepartmentRepository();
        }

        public ActionResult Index()
        {
            List<ViewDepartment> lstDeparments = new List<ViewDepartment>();

            foreach (var item in iDepartment.GetDepartment(new Department()))
            {
                lstDeparments.Add(new ViewDepartment()
                {
                    DepartmentId = item.DepartmentId,
                    DepartmentName = item.DepartmentName
                });
            }

            return View(lstDeparments);
        }

        [HttpGet]
        public ActionResult Create(int? id)
        {
            ViewDepartment viewDepartment = new ViewDepartment();

            if (id != null)
            {
                Department department = iDepartment.GetDepartment(new Department() { DepartmentId = Convert.ToInt32(id) }).FirstOrDefault();
                viewDepartment.DepartmentId = department.DepartmentId ;
                viewDepartment.DepartmentName = department.DepartmentName;
            }

            return View(viewDepartment);
        }

        [HttpPost]
        public ActionResult Create(ViewDepartment viewDepartment)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Department department = new Department()
                    {
                        DepartmentName = viewDepartment.DepartmentName
                    };

                    iDepartment.AddDepartment(department);
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                return View();
            }
            return RedirectToAction("Index");
        }
    }
}